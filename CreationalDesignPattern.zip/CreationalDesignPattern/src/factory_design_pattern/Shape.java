package factory_design_pattern;

public interface Shape {
	void draw();

}
