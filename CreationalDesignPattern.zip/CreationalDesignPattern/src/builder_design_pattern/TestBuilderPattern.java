package builder_design_pattern;

public class TestBuilderPattern {

	public static void main(String[] args) {
		
		Computer computer = new Computer.ComputerBuilder("500GB", "2GB", false, false).setBluetoothEnabled(true).setGraphicsCardEnabled(true).build();
		System.out.println("Computer "+computer.getHDD());
		System.out.println("Computer "+computer.getRAM());
		System.out.println("Computer "+computer.isBluetoothEnabled());
		System.out.println("Computer "+computer.isGraphicsCardEnabled());
	}

}
