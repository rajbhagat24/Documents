package prototype_design_pattern;

public class PrototypePatternDemo {

	public static void main(String[] args) {
		Employee emp1 = new Employee(101, "Raj");
		Employee emp2 = (Employee)emp1.clone();
		
		System.out.println(emp1);
		System.out.println(emp2);
		
		System.out.println("Are both objects same ? "+(emp1 == emp2));

	}

}
