package prototype_design_pattern;

public class Employee implements Prototype {
	private int id;
	private String name;
	
	public Employee(int id, String name) {
		this.id = id;
		this.name = name;
	}
	
	// Copy constructor(for deep cloning if needed)
	public Employee(Employee emp) {
		this.id = emp.id;
		this.name = emp.name;
	}
	
	@Override
	public Prototype clone() {
		return new Employee(this);    //deep copy
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + "]";
	}

}
