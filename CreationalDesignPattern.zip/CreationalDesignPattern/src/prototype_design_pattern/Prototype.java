package prototype_design_pattern;

public interface Prototype {
	Prototype clone();
}
